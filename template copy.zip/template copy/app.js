console.log("KIM Jong un sUPREME LEADER!!!!!!");
var c= docmunt.getElementById('MyCanvas');
var ctx =c. getContext("2d");